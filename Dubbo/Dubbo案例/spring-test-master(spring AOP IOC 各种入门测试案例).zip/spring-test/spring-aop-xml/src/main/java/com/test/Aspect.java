package com.test;


//切面
public class Aspect {
	public void begincommit(){
		System.out.println("before commit");
	}
	
}
