package com.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorldTest {
	/**
	 * 在spring容器中的对象，默认情况下是单例的
	 *    因为对象是单例的，所以只要在类上声明一个属性，该属性中含有数据，那么该属性是全局的
	 */
	@Test
	public void testScope_Default(){
		ApplicationContext context = 
				 new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld");
		HelloWorld helloWorld2 = (HelloWorld)context.getBean("helloWorld");
		System.out.println(helloWorld);
		System.out.println(helloWorld2);
	}
	
	/**
	 * 如果说scope为"prototype"的时候，spring容器产生的对象就是多实例
	 *    无论lazy-init为什么值，都是在context.getBean时才要创建对象
	 */
	@Test
	public void testScope_Prototype(){
		ApplicationContext context = 
				 new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld2");
		HelloWorld helloWorld2 = (HelloWorld)context.getBean("helloWorld2");
		System.out.println(helloWorld);
		System.out.println(helloWorld2);
	}
}
