package com.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DTXMLTest {
	@Test
	public void testDI_XML_Setter(){
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Person person = (Person)context.getBean("person");
		System.out.println(person.getName());
		System.out.println(person.getPid());
	}
}
