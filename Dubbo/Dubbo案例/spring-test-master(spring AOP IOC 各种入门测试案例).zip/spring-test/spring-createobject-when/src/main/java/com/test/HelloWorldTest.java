package com.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorldTest {
	/**
	 * 在默认的情况下，启动spring容器的时候创建对象
	 *    因为是在spring容器启动的时候就创建对象，所以只要配置文件书写错误，在一开始的时候(web容器启动)就能发现错误了
	 */
	@Test
	public void testHelloWorld_Default(){
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld");
		helloWorld.hello();
	}
	
	/*
	 * <bean id="helloWorld2" 
		class="com.itheima12.spring.createobject.when.HelloWorld" 
		lazy-init="true"></bean>
		在context.getBean时才要创建该对象
	 */
	@Test
	public void testHelloWorld_Lazy_init_TRUE(){
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld");
		HelloWorld helloWorld2 = (HelloWorld)context.getBean("helloWorld2");
		helloWorld.hello();
	}
}
