package com.test.dao;

public interface PersonDao {
	public void savePerson();
}
