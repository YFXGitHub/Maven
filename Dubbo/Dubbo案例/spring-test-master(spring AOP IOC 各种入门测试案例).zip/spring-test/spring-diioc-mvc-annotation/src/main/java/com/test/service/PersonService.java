package com.test.service;

public interface PersonService {
	public void savePerson();
}
