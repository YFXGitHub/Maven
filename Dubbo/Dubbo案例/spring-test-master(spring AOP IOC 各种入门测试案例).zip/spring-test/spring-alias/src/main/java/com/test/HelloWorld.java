package com.test;

public class HelloWorld {
	public void hello(){
		System.out.println("hello world");
	}
}
