package com.test;

import org.springframework.stereotype.Component;

@Component("student")
public class Student {
	public void say(){
		System.out.println("student");
	}
}
