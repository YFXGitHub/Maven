package com.test;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

@Component("person")
public class Person {
	@Resource(name="student")
	private Student student;

	public Student getStudent() {
		return student;
	}
}
