package com.test;

public class Student extends Person{

}
