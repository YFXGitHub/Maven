package com.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExtendsTest {
	@Test
	public void testExtends(){
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		Student student = (Student)context.getBean("student");
		System.out.println(student.getName());
	}
}
