package com.test;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Person {
	private Long pid;
	private String name;
	private Student student;
	private List lists;
	private Set sets;
	private Map map;
	private Properties properties;
	private Object[] objects;
	
	public Person(){}
	
	public void setPid(Long pid) {
		this.pid = pid;
	}



	public void setName(String name) {
		this.name = name;
	}



	public void setStudent(Student student) {
		this.student = student;
	}



	public void setLists(List lists) {
		this.lists = lists;
	}



	public void setSets(Set sets) {
		this.sets = sets;
	}



	public void setMap(Map map) {
		this.map = map;
	}



	public void setProperties(Properties properties) {
		this.properties = properties;
	}



	public void setObjects(Object[] objects) {
		this.objects = objects;
	}



	public Person(String name){
		this.name = name;
	}
	
	
	
	public Person(String name, Student student) {
		super();
		this.name = name;
		this.student = student;
	}



	public Long getPid() {
		return pid;
	}
	public String getName() {
		return name;
	}
	public Student getStudent() {
		return student;
	}
	public List getLists() {
		return lists;
	}
	public Set getSets() {
		return sets;
	}
	public Map getMap() {
		return map;
	}
	public Properties getProperties() {
		return properties;
	}
	public Object[] getObjects() {
		return objects;
	}
}
