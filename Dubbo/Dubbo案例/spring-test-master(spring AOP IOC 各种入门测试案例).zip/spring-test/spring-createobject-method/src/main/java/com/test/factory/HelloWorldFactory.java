package com.test.factory;

import com.test.HelloWorld;

public class HelloWorldFactory {
	public static HelloWorld getInstance(){
		return new HelloWorld();
	}
}
