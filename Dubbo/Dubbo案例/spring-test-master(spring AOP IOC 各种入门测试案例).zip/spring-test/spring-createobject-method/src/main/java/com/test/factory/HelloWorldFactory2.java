package com.test.factory;

import com.test.HelloWorld;

public class HelloWorldFactory2 {
	public HelloWorld getInstance(){
		return new HelloWorld();
	}
}
