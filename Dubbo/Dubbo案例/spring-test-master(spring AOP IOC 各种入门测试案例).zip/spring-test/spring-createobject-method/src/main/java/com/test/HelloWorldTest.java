package com.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorldTest {
	/**
	 * 在spring容器中，默认情况下调用了一个类的默认的构造函数创建对象
	 */
	@Test
	public void testCreateObject_Default(){
		//启动spring容器
		ApplicationContext context = 
					new ClassPathXmlApplicationContext("applicationContext.xml");
		//根据id把spring容器中的bean提取出来了
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld");
		helloWorld.hello();
	}
	
	/**
	 * 利用静态工厂模式创建对象
	 * <bean id="helloWorld2" 
		class="com.itheima12.spring.createobject.method.factory.HelloWorldFactory"
		factory-method="getInstance"></bean>
		  spring容器内部调用了HelloWorldFactory中的getInstance方法创建对象
		      而具体的new对象的过程是由程序员来完成的。
	 */
	@Test
	public void testCreateObject_StaticFactory(){
		//启动spring容器
		ApplicationContext context = 
					new ClassPathXmlApplicationContext("applicationContext.xml");
		//根据id把spring容器中的bean提取出来了
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld2");
		helloWorld.hello();
	}
	
	/**
	 * 实例工厂方法
	 */
	@Test
	public void testCreateObject_InstaceFactory(){
		//启动spring容器
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld3");
		helloWorld.hello();
	}
}
