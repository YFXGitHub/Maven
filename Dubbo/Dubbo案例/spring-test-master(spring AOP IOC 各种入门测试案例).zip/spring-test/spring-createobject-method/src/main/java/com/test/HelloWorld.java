package com.test;

public class HelloWorld {
	public HelloWorld(){
		System.out.println("create object");
	}
	public void hello(){
		System.out.println("hello world");
	}
}
