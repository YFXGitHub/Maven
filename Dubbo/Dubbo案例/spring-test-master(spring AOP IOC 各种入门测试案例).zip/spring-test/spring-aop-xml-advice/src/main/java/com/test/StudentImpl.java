package com.test;

public class StudentImpl implements Student {
	public void saveStudent() {
		System.out.println("save student");
	}
}
