package com.test;

import org.springframework.stereotype.Component;

@Component("student")
public class StudentImpl implements Student {
	public void saveStudent() {
		System.out.println("save student");
	}
}
