package com.test;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class Transaction {
	@Pointcut("execution(* com.test.StudentImpl.*(..))")
	private void aa(){}  //方法签名
	
	@Before("aa()")
	public void begincommit(){
		System.out.println("begin begincommit");
	}
	
	@AfterReturning("aa()")
	public void commit(){
		System.out.println("after commit");
	}
}
