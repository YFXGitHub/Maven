package com.test;

public interface Student {
	public void saveStudent();
}
