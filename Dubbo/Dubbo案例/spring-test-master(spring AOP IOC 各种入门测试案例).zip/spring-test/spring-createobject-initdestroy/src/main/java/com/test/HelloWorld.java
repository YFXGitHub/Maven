package com.test;

public class HelloWorld {
	public HelloWorld(){
		System.out.println("aaaa");
	}
	public void hello(){
		System.out.println("hello world");
	}
	
	public void init(){
		System.out.println("init");
	}
	
	public void destroy(){
		System.out.println("destroy");
	}
}
