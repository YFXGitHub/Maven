package com.test;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;


public class Person {
	@Resource(name="student")
//	@Autowired  //按照类型进行匹配
//	@Qualifier("student")
	private Student student;

	public Student getStudent() {
		return student;
	}
}
