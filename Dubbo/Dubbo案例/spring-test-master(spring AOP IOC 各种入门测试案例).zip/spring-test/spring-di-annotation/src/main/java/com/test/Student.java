package com.test;

public class Student {
	public void say(){
		System.out.println("student");
	}
}
