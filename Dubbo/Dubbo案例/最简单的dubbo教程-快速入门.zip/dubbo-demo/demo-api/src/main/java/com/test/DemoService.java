package com.test;

public interface DemoService{  
     String sayHello(String name);  
} 
