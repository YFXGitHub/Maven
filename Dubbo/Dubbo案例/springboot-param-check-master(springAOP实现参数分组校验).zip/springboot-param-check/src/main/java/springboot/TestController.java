package springboot;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
    @RequestMapping("/createChack")
    public Object createChack(@Validate(groups={Create.class}) Student student) {
        return student;
    }
    
    @RequestMapping("/updateChack")
    public Object updateChack(@Validate(groups={Update.class}) Student student) {
        return student;
    }
    
}