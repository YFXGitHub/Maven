package springboot;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Student {
   @NotNull(message="id:不能为空",groups={Update.class})
	@Size(min = 3, max = 20, message = "id长度只能在3-20之间", groups = { Update.class})
	private String id;
	@NotNull(message = "姓名不能为空", groups = {Create.class})
	private String name;
	private String age;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

}
