package springboot;

public interface Update{
  
}

