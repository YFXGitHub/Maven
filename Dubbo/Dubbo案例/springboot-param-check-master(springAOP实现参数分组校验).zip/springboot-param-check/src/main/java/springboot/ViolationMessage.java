package springboot;

import java.io.Serializable;

public class ViolationMessage implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String property;
	private String message;
	
	public ViolationMessage() {
		super();
	}

	public ViolationMessage(String property, String message) {
		super();
		this.property = property;
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "ViolationMessage [property=" + property + ", message="
				+ message + "]";
	}
	
	public String getProperty() {
		return property;
	}
	
	public void setProperty(String property) {
		this.property = property;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
