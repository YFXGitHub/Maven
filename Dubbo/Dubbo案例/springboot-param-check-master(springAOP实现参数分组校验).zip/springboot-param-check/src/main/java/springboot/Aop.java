package springboot;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component // 加入到IoC容器
@Aspect // 指定当前类为切面类
public class Aop {
	@Autowired
	protected Validator validator;

	//@Pointcut("@annotation(springboot.Validate)")
	@Pointcut("execution(* springboot.*.*(..))")
	public void pointCut() {

	}

	@Around("pointCut()")
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
		MethodSignature signature = (MethodSignature) joinPoint.getSignature();
		Method method = signature.getMethod();
		// 获取当前方法
		Parameter[] parameters = method.getParameters();
		if (parameters != null && parameters.length > 0) {
			for (int j = 0; j < parameters.length; j++) {
				Parameter parameter = parameters[j];
				Validate validate = parameter.getAnnotation(Validate.class);// 获取参数的注解
				if (validate != null) {
					Object arg = joinPoint.getArgs()[j];// 获取到参数
					Class<?>[] groups = validate.groups();// 获取注解参数，验证组
						List<ViolationMessage> violationErrors =groups.length!=0?beanValidator(arg, groups):beanValidator(arg);// 参数有效性验证
						if (violationErrors != null) {
							return violationErrors;// 验证不通过，返回结果
						}
				}
			}
		}

		return joinPoint.proceed();
	}

	public List<ViolationMessage> beanValidator(Object object, Class<?>... groups) {
		Set<ConstraintViolation<Object>> constraintViolations = validator.validate(object, groups);
		if (!constraintViolations.isEmpty()) {
			List<ViolationMessage> list = new ArrayList<>();
			ViolationMessage vm = new ViolationMessage();
			for (ConstraintViolation<Object> cv : constraintViolations) {
				vm = new ViolationMessage();
				vm.setProperty(cv.getPropertyPath().toString());
				vm.setMessage(cv.getMessageTemplate());
				list.add(vm);
			}
			return list;
		}
		return null;
	}

}