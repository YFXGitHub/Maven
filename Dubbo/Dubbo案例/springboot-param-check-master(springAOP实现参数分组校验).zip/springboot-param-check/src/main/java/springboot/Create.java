package springboot;

public interface Create {

}
