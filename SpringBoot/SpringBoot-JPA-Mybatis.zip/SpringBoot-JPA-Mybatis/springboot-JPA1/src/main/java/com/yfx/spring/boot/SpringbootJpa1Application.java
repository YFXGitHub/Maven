package com.yfx.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJpa1Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootJpa1Application.class, args);
    }

}
