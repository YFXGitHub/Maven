package com.yfx.springbootmybatis2.config;

import org.springframework.context.annotation.Configuration;

//@Configuration              //此注解表名这是一个配置类
public class MybatisConfig {


}
